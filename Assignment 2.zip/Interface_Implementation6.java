package OOPS_Test1;

interface Payment{
	
	void makePayment();
}

class UPI implements Payment{
	
	public void makePayment()
	{
		
		System.out.println("Payment is successful");
		
	}
	
class CreditCard implements Payment{
	
	public void makePayment() {
		
		System.out.println("Payment is failed");
	}
	
}
}

public class Interface_Implementation6 {

	public static void main(String[] args) {
		
		Payment ref= new UPI();
		ref.makePayment();
		
		Payment ref1=new CreditCard();
		ref1.makePayment();
	}

}
