package OOPS_Test1;

class Account{
	
	private String accountHolderName;
	private double balance;
	
	
	//getter
	public String getAccountHolderName() {
		return accountHolderName;
	}
	
	//setter
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	
	public void setBalance(double balance) {
		
		if(balance<0) {
			
			System.out.println("Warning:Balance can not be negative");
		}else {
		
		this.balance = balance;
	}
	}
	
		public double getBalance() {
			return balance;
		}
	
}

public class Encapsulation_12 {

	public static void main(String[] args) {
		
		Account obj=new Account();
		obj.setAccountHolderName("Ashwini");
		obj.setBalance(5000);
		
		System.out.println("Account Holder:"+ obj.getAccountHolderName());
		System.out.println("Balance:"+ obj.getBalance());
		
		obj.setBalance(-1000);
		System.out.println("Updated Balance: " + obj.getBalance());
	}

}
