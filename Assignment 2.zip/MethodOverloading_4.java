package OOPS_Test1;

class Calculator{
	//method 1- add two integers
	int add(int a,int b)
	{
	return a+b;
	}
	
	//method 2- add two double values
	double add(double a,double b) {
		
	return a+b;
	}
}

public class MethodOverloading_4 {

	public static void main(String[] args) {
		
		Calculator obj=new Calculator();
		System.out.println("Addition of integers: " + obj.add(5, 10));
		System.out.println("Addition of doubles: " + obj.add(5.5, 10.8));

	}

}
