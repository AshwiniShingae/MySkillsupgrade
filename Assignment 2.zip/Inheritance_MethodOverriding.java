package OOPS_Test1;

class Vehicle{
	void fuelType() {
		System.out.println("Runs on fuel");
	}
}
class ElectricCar extends Vehicle{
	void fuelType() {
		System.out.println("Runs on Electricity");
	}
}

public class Inheritance_MethodOverriding {

	public static void main(String[] args) {
		
		ElectricCar obj=new ElectricCar();
		obj.fuelType();
		
		Vehicle obj1=new Vehicle();
		obj1.fuelType();
		 
				

	}

}
