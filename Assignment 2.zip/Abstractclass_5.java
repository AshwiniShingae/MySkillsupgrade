package OOPS_Test1;

abstract class Animal{
	
	abstract void sound();
	
}

class Dog extends Animal{
	
	void sound() {
		
		System.out.println("Dog is barking"); 
	}
}

class Cat extends Animal{
	
	void sound() {
		System.out.println("Cat is meawing");
	}
}

public class Abstractclass_5 {

	public static void main(String[] args) {
		
		Animal ref= new Dog();
		ref.sound();
		
		Animal ref1=new Cat();
		ref1.sound();	
	}
}
