package OOPS_Test1;

class Camera{
	
	void capture() {
		System.out.println("Camera captures very beautiful pictures");
	}
}

class DSLCamera extends Camera{
	
	void capture() {
		
		
		System.out.println("DSLCamera is extremely captures amazing images");
	}
}

public class Polymorphism_Runtime_Upcasting_19 {

	public static void main(String[] args) {
		
		Camera ref=new DSLCamera();
		ref.capture();
		
		
	}

}
