
package OOPS_Test1;

class Shape1
{
	int length;
	
	Shape1(int length){
		this.length=length;
	}
	
	
	void AreaOfSquare() {
		  System.out.println("Area Of Square :" + length*length );
       
	}
	
	void AreaOfRectangle() {
		
		int width=20;
		
		System.out.println("Area of Rectangle :" + length*width );
	}
	


   void AreaOfCircle() {
	   
	   System.out.println("Area of Circle :" + Math.PI*length);
	   
   }
   
}
public class WAP_24 {

	public static void main(String[] args) {
		
		Shape1 obj= new Shape1(5);
		obj.AreaOfSquare();
		obj.AreaOfRectangle();
		obj.AreaOfCircle();
	}

}



