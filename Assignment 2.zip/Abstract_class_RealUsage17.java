package OOPS_Test1;

abstract class Employee2{
	
	String name;
	 
    Employee2(String name) {
        this.name = name;
    }
 
    // Abstract method
    abstract double calculateSalary();
 
    // Concrete method
    void employeeDetails() {
        System.out.println("Employee Name: " + name);
        System.out.println("Salary: " + calculateSalary());
    }
}
 
class FullTimeEmployee extends Employee2 {
 
    double monthlySalary;
 
    FullTimeEmployee(String name, double monthlySalary) {
        super(name);
        this.monthlySalary = monthlySalary;
    }
 
    @Override
    double calculateSalary() {
        return monthlySalary;
    }
}
 
class PartTimeEmployee extends Employee2 {
 
    int hoursWorked;
    double hourlyRate;
 
    PartTimeEmployee(String name, int hoursWorked, double hourlyRate) {
        super(name);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }
 
    @Override
    double calculateSalary() {
        return hoursWorked * hourlyRate;
    }
}
public class Abstract_class_RealUsage17 {

	public static void main(String[] args) {

		
		Employee2 ref1 = new FullTimeEmployee("Rahul", 50000);
        Employee2 ref2 = new PartTimeEmployee("Priya", 80, 300);
 
        ref1.employeeDetails();
 
        System.out.println("-------------------");
 
        ref2.employeeDetails();
	}

}
