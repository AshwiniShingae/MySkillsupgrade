package OOPS_Test1;

class School1
{
	String SchoolName;
	String SchoolAddress;
	int Strength;
	
	School1(String SchoolName, String SchoolAddress){
		this.SchoolName=SchoolName;
		this.SchoolAddress=SchoolAddress;
	}
		
		School1(String SchoolName, String SchoolAddress,int Strength) {
			
			this.SchoolName=SchoolName;
			this.SchoolAddress=SchoolAddress;
			this.Strength=Strength;
		}
		
	
	void display() {
		System.out.println("Name of School :" + SchoolName);
		System.out.println("Address of School :" + SchoolAddress);
		System.out.println("School Strength:"+ Strength);
		System.out.println("______________________");
		
		
	}
}


public class WAP_26 {

	public static void main(String[] args) {
		
      School1 obj= new School1("YHK","Karad");
      obj.display();
      School1 obj1=new School1("Indo British School","Pune", 100);
      obj1.display();
      
		
	}

}

