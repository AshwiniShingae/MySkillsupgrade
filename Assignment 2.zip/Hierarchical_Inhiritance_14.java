package OOPS_Test1;

class Course{
	
	void courseInfo() {
		System.out.println("This is a Course");
	}
}

class Science extends Course{
	
	void scienceInfo() {
		System.out.println("Science contains Subjects : Physics,Chemistry,Biology");
	}
	
}

class Commerce extends Course{
	
	void commerceInfo() {
		
		System.out.println("Commerce contains Subjects : Account, Maths,Economics");
	}
}

class Arts extends Course{
	
	void artsInfo() {
		
		System.out.println("Arts contain Subjects: History , Geography, Marathi");
	}
}
public class Hierarchical_Inhiritance_14 {

	public static void main(String[] args) {
		
		Arts obj=new Arts();
		obj.courseInfo();
		obj.artsInfo();
		
		Science obj1=new Science();
		obj1.scienceInfo();
		
		Commerce obj2=new Commerce();
		obj2.commerceInfo();
		

	}

}
