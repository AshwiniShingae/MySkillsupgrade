package OOPS_Test1;

class University {
	
	static String country="India";
	String universityName;
	
	University(String b){
		
		universityName=b;
	}
	
	void show() {
		
		//System.out.println(country +"  "+ universityName);
		System.out.println("Country :"+ country);
		System.out.println("University Name:"+universityName );
	
	}	
}

public class Static_Concepts_21 {

	public static void main(String[] args) {
	
     University obj=new University("Pune University");
     obj.show();
		
	}
}
