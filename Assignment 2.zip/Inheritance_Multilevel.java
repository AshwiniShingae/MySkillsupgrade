package OOPS_Test1;

class Device{
	
	void start() {
		System.out.println("Device is starting");
	}
}

class Mobile extends Device{
	void calling() {
		System.out.println("Mobile is calling");
	}
}

class smartPhone extends Mobile{
	void internet() {
		System.out.println("Smartphone is using internet");
	}
}
public class Inheritance_Multilevel {

	public static void main(String[] args) {
	
		
		smartPhone obj=new smartPhone();
		obj.start();
		obj.calling();
		obj.internet();
		
	}

}
