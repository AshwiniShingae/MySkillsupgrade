package OOPS_Test1;

class Student1
{
	 static String collegeName="Government college";
	 String Name;
	 int rollNo;
	 
	 Student1(String Name, int rollNo){
		 
		 this.Name=Name;
		 this.rollNo=rollNo;
	 }	 
	
	 void display()
{
System.out.println("Student Name:"+Name);
System.out.println("Student Roll no:"+ rollNo);
System.out.println("College Name:"+ collegeName);
}
}

public class Static_Keyword_10 {

	public static void main(String[] args) {
		
Student1 obj=new Student1("Ash",9);
obj.display();

		
		
		
	}

}
