package OOPS_Test1;

class Person
{
	Person(){
		System.out.println("Person created");
	}
}

class Student extends Person {
    
    Student() {
        super(); // Calls the parent class constructor
        System.out.println("Student Created");
    }
}

public class Super_Keyword_7 {
    public static void main(String[] args) {
        Student obj = new Student();
    }
}