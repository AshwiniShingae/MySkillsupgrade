package OOPS_Test1;

class Engine{
	
	void EngineInfo() {
		System.out.println("Engine : 2000cc Diesel Engine");
	}
	
}

class car{
	
	Engine engine;
	//constructor receives an existing engine object
	car(Engine engine){
		this.engine=engine;
	}
	
	
	void showcarDetails()

	{
		System.out.println("Car Details");
		engine.EngineInfo();
	}
}

public class Aggregation_HASA_Relation_20 {

	public static void main(String[] args) {
		
		Engine obj=new Engine();
	     car obj1=new car(obj);
	 
	      obj1.showcarDetails();

	}

}
