package OOPS_Test1;

class School{
	
	String name;
	School(){
		
		System.out.println("Name of School :" + name);
	}
	
	void display() {
		
		System.out.println("This School is based out of Kolkata");
	}
	
}

public class WAP_25 {

	public static void main(String[] args) {
		
       School obj = new School();   //calling the constructor
       obj.display();
       
		
		
	}

}
