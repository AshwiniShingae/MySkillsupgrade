package OOPS_Test1;

class loanCalculator{
	
	void calculateLoan(int amount) {
		
		System.out.println("Loan Amount :"+ amount);
		System.out.println("Interest Rate is not specified here");
		
	}
		
	void calculateLoan(int amount, double interestRate) {
		
		double interest= (amount*interestRate)*100;
		
		System.out.println("Loan Amount :"+ amount);
		System.out.println("Loan Interest Rate:"+ interestRate + "%");
		System.out.println("Interest amount : " + interest);
		
	}
		
	}


public class Overloading_15 {

	public static void main(String[] args) {
		
		
		loanCalculator obj=new loanCalculator();
		obj.calculateLoan(6400000);
		obj.calculateLoan(6400000,7.8);
	}

}
