package OOPS_Test1;

class Employee
{
	private int empId;
	private String empName;
	double salary;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	public void displaydetails()
	{
		System.out.println("Employee ID: "+ empId);
		System.out.println("Employee Name: "+ empName);
		System.out.println("Employee Salary: "+ salary);
	}	
	
}

public class EncapsulationP1 {

	public static void main(String[] args) {
		
		Employee obj=new Employee();
	  
          obj.setEmpId(100);
          obj.setEmpName("Ashwini");
          obj.setSalary(750000);
          
          obj.displaydetails();
          
          System.out.println("Using Getter Employee ID: "+ obj.getEmpId());
          System.out.println("Employee Name: "+ obj.getEmpName());
          System.out.println("Employee Salary: "+ obj.getSalary());
	}

}
