package OOPS_Test1;

class Product
{
	//Instance variables
	int productId;
	String productName;
	double price;
	
	//default constructor
	Product(){
		System.out.println("Product Created");
	}	
		//parameterized constructor
		
		Product(int d,String s,double p)
		{
			productId=d;
			productName=s;
			price=p;
		}
		
		//method to print product details
		void displayproduct() {
			
			System.out.println("Product Id: "+ productId);
			System.out.println("Product Name: " + productName);
			System.out.println("Price: "+ price);
		}
	}

public class Constructor_Overloading {

	public static void main(String[] args) {
		
		//object using default constructor
		Product obj=new Product();
		obj.displayproduct();
		
		//object using parameterized constructor
		
		Product obj1=new Product(5,"Orange",30);
		obj1.displayproduct();	
	}

}
