package OOPS_Test1;

class Shape
{
	void Area()
	{
		System.out.println("Area of shape");
	}
}

class Rectangle extends Shape
{
	int length=10;
	int width=5;
	
	@Override
	void Area()
	{
		System.out.println("Area of Rectangle :" + (length*width));
	}
}

class Circle extends Shape
{
	int radius=7;
	
	@Override
	void Area()
	{
		System.out.println( "Area of Circle: "+ (Math.PI*radius*radius));
	}
}


public class Polymorphism_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Shape ref=new Rectangle();
		ref.Area();
		
		Shape ref1=new Circle();
		ref1.Area();
		
		
	}

}
