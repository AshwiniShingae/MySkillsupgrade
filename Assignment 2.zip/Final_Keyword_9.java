package OOPS_Test1;

class Bank{
	
	final String IFSC ="HDFC0001234";
	final void showIFSC() {
		System.out.println("Bank IFSC code : "+ IFSC);
		
	}
}

class HDFC extends Bank{
	/*
	@override
	void showIFSC()
	{
		System.out.println("HDFC bank IFSC");
	}
	*/
}

public class Final_Keyword_9 {

	public static void main(String[] args) {
		
		HDFC obj= new HDFC();
		obj.showIFSC();
		
	}

}
