package OOPS_Test1;


interface Transport{
	
	void booking();
	
}

class Bus implements Transport{
	
	public void booking() {
		
		System.out.println("Bus tickets are booked successfully");
	}
	
}

class Flight implements Transport{
	
	

	@Override
	public void booking() {
		
		System.out.println("Flight tickets are bokked successfully");
		
	}
}

public class Interface_multipleImplementations_18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Transport ref=new Bus();
		ref.booking();
		Transport ref1=new Flight();
		ref1.booking();
		
		
	}

}
