package OOPS_Test1;

class Mall{
	
	
	//default constructor
	Mall(){
		
		System.out.println("Welcome to the Mall");

	}
	//parameterized constructor
	
	Mall(String MallAddress){
		
		this();    //call the default constructor
		
		System.out.println("Mall Address :" + MallAddress);
	}
}

public class Constructor_Chaining_23 {

	public static void main(String[] args) {
		
        Mall obj=new Mall();
        
        System.out.println("-------------------------");
        Mall obj1=new Mall("Wagholi");
		
	}

}
