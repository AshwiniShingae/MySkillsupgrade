package OOPS_Test1;

class governmentRules{
	
	final int MAX_WORKING_HOURS=10;
	
	
}

public class FinalKeyword_constant_22 {

	public static void main(String[] args) {
		
		governmentRules obj = new governmentRules();
		
		System.out.println("Maximum Working hours:" + obj.MAX_WORKING_HOURS);
		
	}

}
