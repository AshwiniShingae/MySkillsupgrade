package OOPS_Test1;

class Library{
	 String libraryName;
	 
	 Library(){
		 System.out.println("Welcome to Library!");
	 }
	 
	 void showLocation() {
		 
		 System.out.println("This library is located in Mumbai");
	 }
}

public class Class_Object_Method_11 {

	public static void main(String[] args) {
		
Library obj=new Library();
obj.showLocation();
		
		
	}

}
