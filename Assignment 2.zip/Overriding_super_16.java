package OOPS_Test1;

class Hospital 
{
	void emergencyService()
	{
		System.out.println("Hospital provides an emergency Service in emergency");
	}
}

class cityHospital extends Hospital
{
	void emergencyService()
	
	{
		super.emergencyService();
		System.out.println("City Hospital provides 24/7 emergency services with facilities");
	}
}

public class Overriding_super_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		cityHospital obj =new cityHospital();
		obj.emergencyService();
		
	}

}
